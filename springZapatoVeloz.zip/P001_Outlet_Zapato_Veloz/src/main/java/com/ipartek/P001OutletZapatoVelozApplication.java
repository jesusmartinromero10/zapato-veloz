package com.ipartek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P001OutletZapatoVelozApplication {

	public static void main(String[] args) {
		SpringApplication.run(P001OutletZapatoVelozApplication.class, args);
	}

}
