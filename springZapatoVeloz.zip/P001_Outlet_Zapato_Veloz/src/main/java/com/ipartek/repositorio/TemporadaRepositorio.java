package com.ipartek.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ipartek.modelo.Temporada;

public interface TemporadaRepositorio extends JpaRepository<Temporada, Integer>{


}
