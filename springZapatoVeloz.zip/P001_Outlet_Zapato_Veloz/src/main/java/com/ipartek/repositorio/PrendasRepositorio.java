package com.ipartek.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ipartek.modelo.Prenda;

@Repository
public interface PrendasRepositorio extends JpaRepository<Prenda, Integer>{ //se tiene que conectar con la base de datos con el jpaRepository y se le pasa el objeto que te va a devolver y de que clase es el id x eso es integer que es numerico
	
	@Query(value = "SELECT * FROM prendas WHERE categoria_id = :valor", nativeQuery = true)
	List<Prenda> obtenerPrendasporTipo(@Param("valor") String valor);
}
