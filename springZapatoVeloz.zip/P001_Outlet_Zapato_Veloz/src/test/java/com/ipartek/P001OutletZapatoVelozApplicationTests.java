package com.ipartek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P001OutletZapatoVelozApplicationTests {

	@Test
	void contextLoads() {
	}

}
